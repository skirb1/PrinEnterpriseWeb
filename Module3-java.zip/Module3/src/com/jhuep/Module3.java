package com.jhuep;

public class Module3 {

	public static void main(String[] args) {
		String result_str = "";
		
		if(args.length < 2) {
			System.out.println("Error: missing arguments");
			System.exit(0);
		}
		
		System.out.println("Inputs: " + args[0] + " " + args[1]);
		
		int result = multiply(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
		
		if(result < 0) {
			result_str = "(" + Math.abs(result) + ")";
		}
		else {
			result_str = Integer.toString(result);
		}
		
		System.out.print(result_str);
	}
	
	public static int multiply(int a, int b) {
		return a * b;
	}

}
